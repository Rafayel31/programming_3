let LivingCreature = require('./LivingCreature');
module.exports = class Grass extends LivingCreature{
    constructor(x, y, index) {
        super(x, y, index)
    }
    mul() {
        this.multiply++;
        var newCell = super().chooseCell(0)[Math.floor(super().chooseCell(0).length * Math.random)];
        if (newCell && this.multiply >= 4) {
            var newGrass = new Grass(newCell[0], newCell[1], this.index);
            grassArr.push(newGrass);
            super().matrix[newCell[1]][newCell[0]] = 1;
            this.multiply = 0;
        }
    }
}


