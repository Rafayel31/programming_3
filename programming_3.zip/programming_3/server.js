var express = require('express');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);
var fs = require("fs");
app.use(express.static("."));

app.get('/', function (req, res) {
    res.redirect('index.html');
});
server.listen(3000, () => {
    console.log('connected');
});
//matrix generacnel
var n = 30;
var m = 30;
var matrix = [];
for (var i = 0; i < n; i++) {
    matrix[i] = [];
    for (var o = 0; o < n; o++) {
        matrix[i][o] = Math.round(Math.random() * 5);
    }
}
for (var i = 0; i < n; i++) {
    matrix[i] = [];
    for (var o = 0; o < n; o++) {
        matrix[i][o] = Math.round(5 * Math.random());
    }
}
io.sockets.emit('send matrix', matrix)


var grassArr = [];
var eaterArr = [];
var PredatorArr = [];
var HunterArr = [];
var TerminatorArr = [];

Grass = require('./grass')
GrassEater = require('./grassEator');
Hunter = require('./hunter')
Predator = require('./predator')
Terminator = require('./terminator')
function createObject() {
    for (var y = 0; y < matrix.length; y++) {
        for (var x = 0; x < matrix[y].length; x++) {
            if (matrix[y][x] == 1) {
                var gr = new Grass(x, y, 1);
                grassArr.push(gr);
            }
            if (matrix[y][x] == 2) {
                var gr = new GrassEater(x, y, 2);
                eaterArr.push(gr);
            }
            if (matrix[y][x] == 3) {
                var gr = new Predator(x, y, 3);
                PredatorArr.push(gr);
            }
            if (matrix[y][x] == 4) {
                var gr = new Hunter(x, y, 4);
                HunterArr.push(gr);
            }
            if (matrix[y][x] == 5) {
                var gr = new Terminator(x, y, 5);
                TerminatorArr.push(gr);
            }
        }
    }
}

function game() {
    for (var o in TerminatorArr) {
        TerminatorArr[o].eat(matrix);
        TerminatorArr[o].eat(matrix);
        TerminatorArr[o].mul(matrix);

    }
    for (var o in HunterArr) {
        HunterArr[o].eat(matrix);
        HunterArr[o].eat(matrix);
        HunterArr[o].mul(matrix);

    }
    for (var o in PredatorArr) {
        PredatorArr[o].eat(matrix);
        PredatorArr[o].mul(matrix);

    }
    for (var o in eaterArr) {
        eaterArr[o].eat(matrix);
        eaterArr[o].mul(matrix);

    }

    for (var i in grassArr) {
        grassArr[i].mul(matrix);
    }
    io.sockets.emit("send matrix", matrix);
}

setInterval(game, 1000)

io.on('connection', function () {
    createObject(matrix)
})