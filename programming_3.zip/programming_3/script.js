var socket = io();

function setup() {
    var side = 60;
    createCanvas(side * 30, 30 * side);
    background("grey");

}
function noDraw(matrix) {
    print(matrix)
    for (var y = 0; y < matrix.length; y++) {
        for (var x = 0; x < matrix[y].length; x++) {
            if (matrix[y][x] == 1) {
                fill(255, 0, 0);
                rect(y * side, x * side, side, side);

            }
            if (matrix[y][x] == 2) {
                fill("blue");
                rect(y * side, x * side, side, side);

            }
            if (matrix[y][x] == 3) {
                fill("green");
                rect(y * side, x * side, side, side);

            }
            if (matrix[y][x] == 4) {
                fill("yellow");
                rect(y * side, x * side, side, side);

            }
            if (matrix[y][x] == 5) {
                fill(255, 0, 0);
                rect(y * side, x * side, side, side);

            }
        }
    }

}

setInterval(
    function () {
    socket.on('send matrix', noDraw)
    },1000
)