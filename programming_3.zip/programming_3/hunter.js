let LivingCreature = require('./LivingCreature')
module.exports = class Hunter extends LivingCreature{
    constructor(x, y, index) {
        super(x, y, index)
        this.energy = 15
        this.directions = [
            [this.x - 1, this.y - 1],
            [this.x, this.y - 1],
            [this.x + 1, this.y - 1],
            [this.x - 1, this.y],
            [this.x + 1, this.y],
            [this.x - 1, this.y + 1],
            [this.x, this.y + 1],
            [this.x + 1, this.y + 1],
            [this.x - 2, this.y - 2],
            [this.x, this.y - 2],
            [this.x + 2, this.y - 2],
            [this.x - 2, this.y],
            [this.x + 2, this.y],
            [this.x - 2, this.y + 2],
            [this.x, this.y + 2],
            [this.x + 2, this.y + 2]

        ];

    }
    move(matrix) {
        this.energy--;
        var found = [];
        var newCell = this.chooseCell(0, matrix)[Math.floor(this.chooseCell(0, matrix).length * Math.random)];
        var newCell1 = this.chooseCell(1, matrix)[Math.floor(this.chooseCell(1, matrix).length * Math.random)];
        found.push(newCell);
        found.push(newCell1);
        if (newCell1 || newCell) {

            if (newCell1 && newCell) {
                var rr = Math.round(Math.random());
                var newX = found[rr][0];
                var newY = found[rr][1];
            }
            else if (newCell1 && !newCell) {
                var newX = newCell1[0];
                var newY = newCell1[1];
            }
            else if (!newCell1 && newCell) {
                var newX = newCell[0];
                var newY = newCell[1];
            }

            if (this.a) { matrix[this.y][this.x] = this.a; }
            else { matrix[this.y][this.x] = 0; }
            this.x = newX;
            this.y = newY;
            this.a = matrix[newY][newX];
            matrix[this.y][this.x] = 4;
        }
    }


    eat(matrix) {
        var newCell = this.chooseCell(3, matrix)[Math.floor(this.chooseCell(3, matrix).length * Math.random)];
        if (newCell) {
            var newX = newCell[0];
            var newY = newCell[1];
            matrix[newY][newX] = 4;
            matrix[this.y][this.x] = 0;
            this.x = newX;
            this.y = newY;
            for (var i in PredatorArr) {
                if (newX == PredatorArr[i].x && newY == PredatorArr[i].y) {
                    PredatorArr.splice(i, 1);
                    break;

                }
                this.y = newY;
                this.x = newX;
                this.energy += 2;
            }
        }
        else {
            this.move(matrix);
        }
    }




    mul(matrix) {

        if (this.energy >= 15) {

            var newCell = this.chooseCell(3, matrix)[Math.floor(this.chooseCell(3, matrix).length * Math.random)];
            if (newCell) {
                var neweater = new Hunter(newCell[0], newCell[1], 4);
                HunterArr.push(neweater);
                matrix[newCell[1]][newCell[0]] = 4;
                this.energy = 8;
            }
        }
    }
    die(matrix) {
        if (this.energy <= 0) {
            if (this.a) { matrix[this.y][this.x] = this.a; }
            else { matrix[this.y][this.x] = 0; }
            for (var i in HunterArr) {
                if (this.x == HunterArr[i].x && this.y == HunterArr[i].y) {
                    HunterArr.splice(i, 1);
                    break;
                }
            }
        }

    }
}