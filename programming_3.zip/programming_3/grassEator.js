let LivingCreature = require('./LivingCreature')
module.exports =  class GrassEater extends LivingCreature{

    constructor(x, y, index) {
        super(x, y, index)
        this.energy = 8;
    }
    

    move() {
        this.energy--;
        var newCell = super().chooseCell(0)[Math.floor(super().chooseCell(0).length * Math.random)];
        if (newCell) {

            console.log(this.energy);
            var newX = newCell[0];
            var newY = newCell[1];
            super().matrix[this.y][this.x] = 0;
            this.x = newX;
            this.y = newY;
            super().matrix[this.y][this.x] = 2;
        }

    }

    eat() {
        var newCell = super().chooseCell(1)[Math.floor(super().chooseCell(1).length * Math.random)];
        if (newCell) {
            var newX = newCell[0];
            var newY = newCell[1];
            super().matrix[newY][newX] = 2;
            super().matrix[this.y][this.x] = 0;
            this.x = newX;
            this.y = newY;
            for (var i in grassArr) {
                if (newX == grassArr[i].x && newY == grassArr[i].y) {
                    grassArr.splice(i, 1);
                    break;
                }
                console.log("eat");
            }
            this.energy += 2;

        } else {
            this.move(super().matrix);
        }
    }




    mul() {

        if (this.energy >= 10) {

            var newCell = super().chooseCell(0,)[Math.floor(super().chooseCell(0).length * Math.random)];
            if (newCell) {
                this.energy = 7;
                var neweater = new GrassEater(newCell[0], newCell[1], this.index);
                eaterArr.push(neweater);
                super().matrix[newCell[1]][newCell[0]] = 2;

            }
        }
    }
    die() {
        if (this.energy <= 0) {
            matrix[this.y][this.x] = 0;
            console.log("fytg");
            for (var i in eaterArr) {
                if (this.x == eaterArr[i].x && this.y == eaterArr[i].y) {
                    eaterArr.splice(i, 1);
                    break;
                }

            }
        }

    }

}
