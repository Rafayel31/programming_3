let LivingCreature = require('./LivingCreature')
module.exports = class Predator extends LivingCreature{

    constructor(x, y, index) {
        super(x, y, index)
        this.energy = 15;
    }

    move(matrix) {
        this.energy--;
        var found = [];
        var newCell = this.chooseCell(0, matrix)[Math.floor(this.chooseCell(0, matrix).length * Math.random)];;
        var newCell1 = this.chooseCell(1, matrix)[Math.floor(this.chooseCell(1, matrix).length * Math.random)];;
        found.push(newCell);
        found.push(newCell1);

        if (newCell) {
            var newX = newCell[0];
            var newY = newCell[1];
            if (this.a) { matrix[this.y][this.x] = this.a; }
            else { matrix[this.y][this.x] = 0; }
            this.x = newX;
            this.y = newY;
            this.a = matrix[newY][newX]
            matrix[this.y][this.x] = 3;
        }

    }

    eat(matrix) {
        var newCell = this.chooseCell(2, matrix)[Math.floor(this.chooseCell(2, matrix).length * Math.random)];;
        if (newCell) {
            var newX = newCell[0];
            var newY = newCell[1];
            matrix[newY][newX] = 3;
            matrix[this.y][this.x] = 0;
            this.x = newX;
            this.y = newY;
            for (var i in eaterArr) {
                if (newX == eaterArr[i].x && newY == eaterArr[i].y) {
                    eaterArr.splice(i, 1);
                    break;
                }
            }
            this.y = newY;
            this.x = newX;
            this.energy += 2;

        } else {
            this.move(matrix);
        }
    }




    mul(matrix) {

        if (this.energy >= 12) {

            var newCell = this.chooseCell(0, matrix)[Math.floor(this.chooseCell(0, matrix).length * Math.random)];
            if (newCell) {
                var neweater = new Predator(newCell[0], newCell[1], this.index);
                PredatorArr.push(neweater);
                matrix[newCell[1]][newCell[0]] = 3;
                this.energy = 6;
            }
        }
    }
    die(matrix) {
        if (this.energy <= 0) {
            matrix[this.y][this.x] = 0;
            for (var i in PredatorArr) {
                if (this.x == PredatorArr[i].x && this.y == PredatorArr[i].y) {
                    PredatorArr.splice(i, 1);
                    break;
                }
            }
        }

    }

}