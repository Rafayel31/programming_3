let LivingCreature = require('./LivingCreature')
module.exports = class Predator extends LivingCreature{

    constructor(x, y, index) {
        super(x, y, index)
        this.energy = 15;
    }

    move() {
        this.energy--;
        var found = [];
        var newCell = super().chooseCell(0)[Math.floor(super().chooseCell(0).length * Math.random)];;
        var newCell1 = super().chooseCell(1)[Math.floor(super().chooseCell(1).length * Math.random)];;
        found.push(newCell);
        found.push(newCell1);

        if (newCell) {
            var newX = newCell[0];
            var newY = newCell[1];
            if (this.a) { super().matrix[this.y][this.x] = this.a; }
            else { super().matrix[this.y][this.x] = 0; }
            this.x = newX;
            this.y = newY;
            this.a = super().matrix[newY][newX]
            super().matrix[this.y][this.x] = 3;
        }

    }

    eat() {
        var newCell = super().chooseCell(2)[Math.floor(super().chooseCell(2).length * Math.random)];;
        if (newCell) {
            var newX = newCell[0];
            var newY = newCell[1];
            super().matrix[newY][newX] = 3;
            super().matrix[this.y][this.x] = 0;
            this.x = newX;
            this.y = newY;
            for (var i in eaterArr) {
                if (newX == eaterArr[i].x && newY == eaterArr[i].y) {
                    eaterArr.splice(i, 1);
                    break;
                }
            }
            this.y = newY;
            this.x = newX;
            this.energy += 2;

        } else {
            this.move(super().matrix);
        }
    }




    mul() {

        if (this.energy >= 12) {

            var newCell = super().chooseCell(0)[Math.floor(super().chooseCell(0).length * Math.random)];
            if (newCell) {
                var neweater = new Predator(newCell[0], newCell[1], this.index);
                PredatorArr.push(neweater);
                super().matrix[newCell[1]][newCell[0]] = 3;
                this.energy = 6;
            }
        }
    }
    die() {
        if (this.energy <= 0) {
            super().matrix[this.y][this.x] = 0;
            for (var i in PredatorArr) {
                if (this.x == PredatorArr[i].x && this.y == PredatorArr[i].y) {
                    PredatorArr.splice(i, 1);
                    break;
                }
            }
        }

    }

}